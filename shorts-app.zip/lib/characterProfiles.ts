export const characterProfiles = [
  {
    name: "민수",
    description:
      "15세 오빠. 키는 또래보다 크고 단정한 검은 단발머리, 짙은 눈썹, 선명한 이중 쌍꺼풀. 헐렁한 후드티와 반바지 착용. 운동화 착용.",
  },
  {
    name: "지수",
    description:
      "13세 여동생. 긴 생머리를 반묶음, 둥근 얼굴형, 큰 눈. 귀여운 인상. 민트색 노브와 모자 착용.",
  },
]; 